(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_5128a5ff._.js",
  "static/chunks/node_modules_dccb3d79._.js"
],
    source: "dynamic"
});
