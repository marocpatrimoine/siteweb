
"use client";

import React, {useState} from 'react';
import {useForm} from 'react-hook-form';
import {zodResolver} from '@hookform/resolvers/zod';
import * as z from 'zod';
import {Form, FormControl, FormField, FormItem, FormLabel, FormMessage} from '@/components/ui/form';
import {Input} from '@/components/ui/input';
import {Textarea} from '@/components/ui/textarea';
import {Button} from '@/components/ui/button';
import {analyzeLeadInquiry, type AnalyzeLeadInquiryOutput} from '@/ai/flows/analyze-lead-inquiry';
import {Loader2, CheckCircle2, ShieldCheck, Mail, Phone, User, Globe} from 'lucide-react';
import {Badge} from '@/components/ui/badge';
import {useToast} from '@/hooks/use-toast';

const formSchema = z.object({
  name: z.string().min(2, "Le nom est requis"),
  email: z.string().email("Email invalide"),
  phone: z.string().min(8, "Numéro de téléphone requis"),
  country: z.string().min(2, "Pays requis"),
  message: z.string().min(20, "Veuillez détailler votre situation (min. 20 caractères)"),
});

export function LeadForm() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [analysis, setAnalysis] = useState<AnalyzeLeadInquiryOutput | null>(null);
  const {toast} = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      country: "",
      message: "",
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSubmitting(true);
    try {
      // Simulate backend storage or actual API call
      console.log("Form submitted:", values);
      
      // Perform AI Analysis using the provided flow
      const result = await analyzeLeadInquiry({
        inquiryText: values.message
      });
      
      setAnalysis(result);
      toast({
        title: "Demande reçue",
        description: "Votre situation a été transmise à nos experts. Analyse préliminaire générée.",
      });
      
    } catch (error) {
      console.error(error);
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Une erreur est survenue lors de l'envoi de votre demande.",
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  if (analysis) {
    return (
      <div className="bg-white rounded-3xl p-8 lg:p-12 shadow-2xl space-y-8 animate-in fade-in zoom-in duration-500">
        <div className="text-center space-y-4">
          <div className="inline-flex p-3 rounded-full bg-green-100 text-green-600 mb-2">
            <CheckCircle2 className="w-12 h-12" />
          </div>
          <h3 className="text-3xl font-headline font-bold text-secondary">Merci, {form.getValues('name')}</h3>
          <p className="text-muted-foreground">Nous avons bien reçu votre demande. Voici une analyse préliminaire de votre cas par notre système intelligent :</p>
        </div>

        <div className="space-y-6 bg-muted/50 p-6 rounded-2xl border border-muted">
           <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Résumé du Cas</span>
              <p className="text-secondary font-medium leading-relaxed italic">&quot;{analysis.summary}&quot;</p>
           </div>
           
           <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Catégories identifiées</span>
              <div className="flex flex-wrap gap-2">
                 {analysis.caseCategories.map((cat, i) => (
                   <Badge key={i} variant="secondary" className="bg-secondary/10 text-secondary border-none px-3 py-1 capitalize">
                     {cat.replace('administrative complexity', 'Complexité Administrative').replace('land dispute', 'Litige Foncier').replace('inheritance', 'Héritage')}
                   </Badge>
                 ))}
              </div>
           </div>

           <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Termes Clés</span>
              <div className="flex flex-wrap gap-1.5">
                 {analysis.keyLegalTerms.map((term, i) => (
                   <span key={i} className="text-xs text-secondary/60 bg-white px-2 py-0.5 rounded border border-secondary/10">{term}</span>
                 ))}
              </div>
           </div>
        </div>

        <div className="text-center">
           <p className="text-sm text-muted-foreground mb-6">Un conseiller spécialisé vous contactera sous 24h ouvrées pour approfondir ces éléments.</p>
           <Button variant="outline" onClick={() => { setAnalysis(null); form.reset(); }} className="rounded-full">Nouvelle demande</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-3xl p-8 lg:p-12 shadow-2xl">
      <div className="flex items-center gap-3 mb-8">
        <ShieldCheck className="w-8 h-8 text-gold" />
        <h3 className="text-2xl font-headline font-bold text-secondary">Lancer mon analyse</h3>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="name"
              render={({field}) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-2"><User className="w-3.5 h-3.5" /> Nom complet</FormLabel>
                  <FormControl>
                    <Input placeholder="Jean Dupont" {...field} className="rounded-xl border-muted focus:border-gold h-12" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="email"
              render={({field}) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-2"><Mail className="w-3.5 h-3.5" /> Email</FormLabel>
                  <FormControl>
                    <Input placeholder="contact@email.com" {...field} className="rounded-xl border-muted focus:border-gold h-12" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="phone"
              render={({field}) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-2"><Phone className="w-3.5 h-3.5" /> Téléphone</FormLabel>
                  <FormControl>
                    <Input placeholder="+33 6 12 34 56 78" {...field} className="rounded-xl border-muted focus:border-gold h-12" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="country"
              render={({field}) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-2"><Globe className="w-3.5 h-3.5" /> Pays de résidence</FormLabel>
                  <FormControl>
                    <Input placeholder="France, Belgique, Canada..." {...field} className="rounded-xl border-muted focus:border-gold h-12" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="message"
            render={({field}) => (
              <FormItem>
                <FormLabel>Détails de votre situation</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Décrivez brièvement le problème : héritage bloqué, litige foncier, titres manquants..." 
                    {...field} 
                    className="rounded-xl border-muted focus:border-gold min-h-[150px] resize-none"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <Button 
            type="submit" 
            className="w-full h-14 rounded-xl bg-primary hover:bg-primary/90 text-secondary font-bold text-lg shadow-lg"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Analyse en cours...
              </>
            ) : (
              "Envoyer pour analyse gratuite"
            )}
          </Button>
          <p className="text-center text-xs text-muted-foreground italic">
            Vos données sont strictement confidentielles et traitées conformément à notre politique de confidentialité.
          </p>
        </form>
      </Form>
    </div>
  );
}
