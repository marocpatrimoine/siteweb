
"use client";

import React, {useState, useEffect} from 'react';
import {MessageCircle, Phone} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {cn} from '@/lib/utils';

export function CTAFloating() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsVisible(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      {/* WhatsApp Floating Button */}
      <a 
        href="https://wa.me/212522000000" 
        target="_blank" 
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 bg-[#25D366] text-white p-4 rounded-full shadow-2xl hover:scale-110 active:scale-95 transition-all duration-300 group"
      >
        <MessageCircle className="w-7 h-7" />
        <span className="absolute right-full mr-3 bg-white text-secondary text-xs font-bold px-3 py-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-md pointer-events-none">
          Besoin d&apos;aide ?
        </span>
      </a>

      {/* Sticky Bottom Bar for Mobile */}
      <div className={cn(
        "md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-muted p-4 transition-transform duration-300",
        isVisible ? "translate-y-0" : "translate-y-full"
      )}>
        <Button className="w-full bg-primary text-secondary font-bold h-12 rounded-xl" asChild>
           <a href="#contact">Étudier ma situation</a>
        </Button>
      </div>

      {/* Desktop Sticky Sidebar Button */}
      <div className={cn(
        "hidden lg:block fixed left-0 top-1/2 -translate-y-1/2 z-40 transition-transform duration-300",
        isVisible ? "translate-x-0" : "-translate-x-full"
      )}>
        <a 
          href="#contact" 
          className="flex items-center gap-3 bg-secondary text-white py-4 px-6 rounded-r-2xl shadow-xl hover:bg-secondary/90 hover:pl-8 transition-all"
        >
          <Phone className="w-5 h-5 text-gold" />
          <span className="font-bold uppercase tracking-widest text-xs">Analyse Gratuite</span>
        </a>
      </div>
    </>
  );
}
