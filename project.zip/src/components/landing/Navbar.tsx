
"use client";

import React, {useState, useEffect} from 'react';
import {Button} from '@/components/ui/button';
import {cn} from '@/lib/utils';
import {ShieldCheck} from 'lucide-react';

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={cn(
      "fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-6 lg:px-12 py-4",
      isScrolled ? "bg-white/95 backdrop-blur-sm shadow-md py-3" : "bg-transparent"
    )}>
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="bg-primary p-1.5 rounded-lg shadow-sm">
            <ShieldCheck className="w-6 h-6 text-white" />
          </div>
          <span className={cn(
            "text-xl font-headline font-bold tracking-tight",
            isScrolled ? "text-secondary" : "text-white"
          )}>
            Moroccan<span className="text-primary">Legal</span>Bridge
          </span>
        </div>
        
        <div className="hidden md:flex items-center gap-8">
          <a href="#services" className={cn("text-sm font-medium hover:text-primary transition-colors", isScrolled ? "text-secondary" : "text-white")}>Services</a>
          <a href="#methodology" className={cn("text-sm font-medium hover:text-primary transition-colors", isScrolled ? "text-secondary" : "text-white")}>Méthodologie</a>
          <a href="#testimonials" className={cn("text-sm font-medium hover:text-primary transition-colors", isScrolled ? "text-secondary" : "text-white")}>Avis</a>
          <Button asChild variant={isScrolled ? "default" : "outline"} className={cn(!isScrolled && "border-white text-white hover:bg-white hover:text-secondary")}>
            <a href="#contact">Étudier ma situation</a>
          </Button>
        </div>

        <div className="md:hidden">
           <Button variant="ghost" size="icon" className={isScrolled ? "text-secondary" : "text-white"}>
             <span className="sr-only">Menu</span>
             <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
           </Button>
        </div>
      </div>
    </nav>
  );
}
