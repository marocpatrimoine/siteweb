
import React from 'react';
import {ShieldCheck, Lock, EyeOff, UserCheck} from 'lucide-react';

export function Confidentiality() {
  return (
    <section className="py-24 bg-corporate-blue overflow-hidden relative">
      {/* Decorative patterns */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />

      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10">
        <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-8 lg:p-16 text-center space-y-12">
           <div className="space-y-4">
              <div className="inline-flex p-4 rounded-2xl bg-gold/20 text-gold mb-4">
                 <ShieldCheck className="w-12 h-12" />
              </div>
              <h2 className="text-3xl md:text-5xl font-headline font-bold text-white">Discrétion & Confidentialité Totale</h2>
              <p className="text-white/60 text-lg max-w-2xl mx-auto">
                La nature de vos biens et de vos affaires juridiques reste strictement confidentielle. Nous appliquons les standards de sécurité les plus élevés.
              </p>
           </div>

           <div className="grid sm:grid-cols-3 gap-8">
              {[
                { icon: Lock, title: "Secret Professionnel", desc: "Tous nos collaborateurs sont liés par une clause de confidentialité stricte." },
                { icon: EyeOff, title: "Données Sécurisées", desc: "Protocoles de cryptage de pointe pour tous vos documents et échanges." },
                { icon: UserCheck, title: "Mandat Exclusif", desc: "Nous agissons uniquement sous votre instruction directe et privée." }
              ].map((item, idx) => (
                <div key={idx} className="space-y-4">
                   <div className="inline-flex p-3 rounded-full bg-white/5 text-gold">
                      <item.icon className="w-6 h-6" />
                   </div>
                   <h3 className="text-xl font-headline font-bold text-white">{item.title}</h3>
                   <p className="text-white/40 text-sm leading-relaxed">{item.desc}</p>
                </div>
              ))}
           </div>
        </div>
      </div>
    </section>
  );
}
