
import React from 'react';
import Image from 'next/image';
import {PlaceHolderImages} from '@/lib/placeholder-images';
import {Star, Quote} from 'lucide-react';

export function Testimonials() {
  const user1 = PlaceHolderImages.find(img => img.id === 'trust-portrait-1');
  const user2 = PlaceHolderImages.find(img => img.id === 'trust-portrait-2');

  const reviews = [
    {
      name: "Karim B.",
      location: "Paris, France",
      text: "Vivant à Paris, il était impossible pour moi de gérer un litige successoral à Tanger. MoroccanLegalBridge a pris le dossier en main et l'a réglé en moins de 6 mois. Un service irréprochable.",
      avatar: user1?.imageUrl
    },
    {
      name: "Nadia L.",
      location: "Bruxelles, Belgique",
      text: "Enfin un cabinet qui comprend les besoins de la diaspora. La transparence est totale et le suivi à distance via WhatsApp est très rassurant. Je recommande vivement pour tout achat foncier.",
      avatar: user2?.imageUrl
    }
  ];

  return (
    <section id="testimonials" className="py-24 bg-muted/50">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <h2 className="text-3xl md:text-4xl font-headline font-bold text-secondary mb-6">Ils nous font confiance</h2>
          <p className="text-muted-foreground text-lg">La voix de nos clients est notre meilleure garantie de succès.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {reviews.map((review, idx) => (
            <div key={idx} className="bg-white p-8 lg:p-12 rounded-3xl shadow-xl border border-muted relative group">
              <Quote className="absolute top-8 right-8 w-12 h-12 text-muted opacity-20 group-hover:text-gold group-hover:opacity-40 transition-all" />
              <div className="flex gap-1 mb-6">
                {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-gold text-gold" />)}
              </div>
              <p className="text-secondary text-lg italic leading-relaxed mb-8">
                &quot;{review.text}&quot;
              </p>
              <div className="flex items-center gap-4">
                <div className="relative w-14 h-14 rounded-full overflow-hidden border-2 border-primary">
                  <Image src={review.avatar || ''} alt={review.name} fill className="object-cover" />
                </div>
                <div>
                  <h4 className="font-headline font-bold text-secondary">{review.name}</h4>
                  <p className="text-muted-foreground text-sm">{review.location}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
