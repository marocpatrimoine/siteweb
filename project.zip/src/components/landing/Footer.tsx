
import React from 'react';
import {ShieldCheck, Mail, Phone, MapPin, Facebook, Instagram, Linkedin} from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-corporate-blue text-white pt-20 pb-10 overflow-hidden relative">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
        <div className="space-y-6">
          <div className="flex items-center gap-2">
            <div className="bg-primary p-1.5 rounded-lg">
              <ShieldCheck className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-headline font-bold">
              Moroccan<span className="text-gold">Legal</span>Bridge
            </span>
          </div>
          <p className="text-white/60 text-sm leading-relaxed">
            Support premium pour la diaspora marocaine en gestion foncière et conseil juridique au Maroc. Expertise, Discrétion, Résultats.
          </p>
          <div className="flex gap-4">
             <a href="#" className="p-2 rounded-full bg-white/5 hover:bg-primary/20 hover:text-gold transition-all"><Facebook className="w-5 h-5" /></a>
             <a href="#" className="p-2 rounded-full bg-white/5 hover:bg-primary/20 hover:text-gold transition-all"><Instagram className="w-5 h-5" /></a>
             <a href="#" className="p-2 rounded-full bg-white/5 hover:bg-primary/20 hover:text-gold transition-all"><Linkedin className="w-5 h-5" /></a>
          </div>
        </div>

        <div className="space-y-6">
          <h4 className="font-headline font-bold text-lg">Services</h4>
          <ul className="space-y-3 text-white/60 text-sm">
            <li><a href="#" className="hover:text-gold transition-colors">Immatriculation Foncière</a></li>
            <li><a href="#" className="hover:text-gold transition-colors">Audit de Patrimoine</a></li>
            <li><a href="#" className="hover:text-gold transition-colors">Droit des Successions</a></li>
            <li><a href="#" className="hover:text-gold transition-colors">Transactions Immobilières</a></li>
          </ul>
        </div>

        <div className="space-y-6">
          <h4 className="font-headline font-bold text-lg">Liens Utiles</h4>
          <ul className="space-y-3 text-white/60 text-sm">
            <li><a href="#" className="hover:text-gold transition-colors">À Propos</a></li>
            <li><a href="#" className="hover:text-gold transition-colors">Méthodologie</a></li>
            <li><a href="#" className="hover:text-gold transition-colors">Témoignages</a></li>
            <li><a href="#" className="hover:text-gold transition-colors">Mentions Légales</a></li>
          </ul>
        </div>

        <div className="space-y-6">
          <h4 className="font-headline font-bold text-lg">Contact</h4>
          <ul className="space-y-4 text-white/60 text-sm">
            <li className="flex items-start gap-3">
              <MapPin className="w-5 h-5 text-gold shrink-0" />
              <span>Boulevard Mohammed V, Casablanca, Maroc</span>
            </li>
            <li className="flex items-center gap-3">
              <Phone className="w-5 h-5 text-gold shrink-0" />
              <span>+212 522 XX XX XX</span>
            </li>
            <li className="flex items-center gap-3">
              <Mail className="w-5 h-5 text-gold shrink-0" />
              <span>contact@moroccanlegalbridge.com</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-12 pt-10 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-6 text-white/40 text-xs">
        <p>© 2024 MoroccanLegalBridge. Tous droits réservés.</p>
        <div className="flex gap-6">
           <a href="#" className="hover:text-white transition-colors">Confidentialité</a>
           <a href="#" className="hover:text-white transition-colors">Conditions Générales</a>
        </div>
      </div>
    </footer>
  );
}
