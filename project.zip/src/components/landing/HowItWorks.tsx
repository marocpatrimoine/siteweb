
import React from 'react';
import {Search, FileCheck, Gavel, CheckCircle} from 'lucide-react';

export function HowItWorks() {
  const steps = [
    {
      icon: Search,
      title: "Analyse",
      desc: "Étude approfondie de votre situation et des documents disponibles."
    },
    {
      icon: FileCheck,
      title: "Vérification",
      desc: "Audit terrain et administratif auprès des instances concernées."
    },
    {
      icon: Gavel,
      title: "Régularisation",
      desc: "Action juridique ou administrative pour assainir le dossier."
    },
    {
      icon: CheckCircle,
      title: "Résolution",
      desc: "Finalisation du dossier et obtention des titres ou actes."
    }
  ];

  return (
    <section id="methodology" className="py-24 bg-white relative">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <h2 className="text-3xl md:text-4xl font-headline font-bold text-secondary mb-6">Notre Méthodologie</h2>
          <p className="text-muted-foreground text-lg">Un processus structuré pour garantir des résultats concrets et mesurables.</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          {steps.map((step, idx) => (
            <div key={idx} className="relative group">
              {idx < steps.length - 1 && (
                <div className="hidden lg:block absolute top-10 left-full w-full h-[2px] bg-muted -translate-x-8 z-0" />
              )}
              <div className="relative z-10 flex flex-col items-center text-center space-y-6">
                <div className="w-20 h-20 rounded-2xl bg-secondary flex items-center justify-center text-gold shadow-lg transform group-hover:-translate-y-2 transition-transform duration-300">
                  <step.icon className="w-10 h-10" />
                  <div className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-primary text-secondary flex items-center justify-center font-bold text-sm border-4 border-white">
                    {idx + 1}
                  </div>
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-headline font-bold text-secondary">{step.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{step.desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
