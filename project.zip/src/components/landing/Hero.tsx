
import React from 'react';
import {Button} from '@/components/ui/button';
import {ShieldCheck, Gavel, Globe, CheckCircle2} from 'lucide-react';
import Image from 'next/image';
import {PlaceHolderImages} from '@/lib/placeholder-images';

export function Hero() {
  const heroImage = PlaceHolderImages.find(img => img.id === 'hero-bg');

  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-corporate-blue">
      {/* Background with overlay */}
      <div className="absolute inset-0 z-0">
        <Image 
          src={heroImage?.imageUrl || ''} 
          alt="Morocco" 
          fill 
          className="object-cover opacity-30 grayscale-[0.5]"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-r from-corporate-blue via-corporate-blue/80 to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-12 grid lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-8 max-w-2xl">
          <div className="space-y-4">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-headline font-bold text-white leading-tight">
              Gestion Foncière & Conseil Juridique au <span className="text-gold">Maroc</span>
            </h1>
            <p className="text-lg md:text-xl text-white/80 font-body leading-relaxed max-w-xl">
              Un pont de confiance pour la diaspora. Nous gérons vos biens, héritages et complexités administratives à distance, en toute confidentialité.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-secondary font-bold text-lg h-14 px-8 rounded-full shadow-lg transition-all hover:scale-105" asChild>
              <a href="#contact">Étudier ma situation</a>
            </Button>
            <Button size="lg" variant="outline" className="text-white border-white/30 hover:bg-white/10 text-lg h-14 px-8 rounded-full backdrop-blur-sm" asChild>
              <a href="#services">Nos services</a>
            </Button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-8">
            <div className="flex items-center gap-3 text-white/90">
              <ShieldCheck className="w-6 h-6 text-gold" />
              <span className="text-sm font-medium">100% Confidentiel</span>
            </div>
            <div className="flex items-center gap-3 text-white/90">
              <Gavel className="w-6 h-6 text-gold" />
              <span className="text-sm font-medium">Expertise Certifiée</span>
            </div>
            <div className="flex items-center gap-3 text-white/90">
              <Globe className="w-6 h-6 text-gold" />
              <span className="text-sm font-medium">Gestion à distance</span>
            </div>
          </div>
        </div>

        <div className="hidden lg:block">
           <div className="relative p-8 rounded-3xl bg-white/5 backdrop-blur-md border border-white/10 shadow-2xl">
              <div className="space-y-6">
                 <div className="flex items-center gap-4 p-4 rounded-xl bg-white/10 border border-white/5">
                    <div className="bg-gold/20 p-2 rounded-lg"><CheckCircle2 className="w-6 h-6 text-gold" /></div>
                    <div>
                       <div className="text-white font-bold">Héritage régularisé</div>
                       <div className="text-white/60 text-xs">Cas traité en 4 mois</div>
                    </div>
                 </div>
                 <div className="flex items-center gap-4 p-4 rounded-xl bg-white/10 border border-white/5 translate-x-8">
                    <div className="bg-gold/20 p-2 rounded-lg"><CheckCircle2 className="w-6 h-6 text-gold" /></div>
                    <div>
                       <div className="text-white font-bold">Titre foncier obtenu</div>
                       <div className="text-white/60 text-xs">Cas de litige complexe</div>
                    </div>
                 </div>
                 <div className="flex items-center gap-4 p-4 rounded-xl bg-white/10 border border-white/5 translate-x-4">
                    <div className="bg-gold/20 p-2 rounded-lg"><CheckCircle2 className="w-6 h-6 text-gold" /></div>
                    <div>
                       <div className="text-white font-bold">Vente sécurisée</div>
                       <div className="text-white/60 text-xs">Accompagnement complet</div>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      </div>
    </section>
  );
}
