
import React from 'react';
import {XCircle, CheckCircle2, MapPin, Scale, Clock, FileWarning} from 'lucide-react';
import {Card, CardContent} from '@/components/ui/card';

export function ProblemSolution() {
  return (
    <div className="py-24 space-y-32 bg-white overflow-hidden">
      {/* Problem Section */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-headline font-bold text-secondary mb-6">
            Vos biens au Maroc ne devraient pas être un fardeau
          </h2>
          <p className="text-muted-foreground text-lg">
            La distance et la complexité administrative marocaine transforment souvent les opportunités en impasses juridiques.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            { icon: Clock, title: "Délais interminables", desc: "Des dossiers qui traînent depuis des années sans issue visible." },
            { icon: MapPin, title: "Barrière de la distance", desc: "Difficulté à suivre les procédures sans être physiquement présent." },
            { icon: FileWarning, title: "Blocages administratifs", desc: "Complexité des titres fonciers et des régulations locales." },
            { icon: Scale, title: "Héritages complexes", desc: "Conflits familiaux ou manque de documentation claire." }
          ].map((item, idx) => (
            <Card key={idx} className="border-none shadow-sm bg-muted/50 hover:shadow-md transition-shadow duration-300">
              <CardContent className="pt-8 pb-6 px-6 text-center space-y-4">
                <div className="inline-flex p-3 rounded-full bg-destructive/10 text-destructive mb-2">
                   <item.icon className="w-6 h-6" />
                </div>
                <h3 className="font-headline font-bold text-xl text-secondary">{item.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{item.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Solution Section */}
      <section className="relative">
        <div className="absolute inset-0 bg-corporate-blue -skew-y-2 origin-left" />
        <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-12 py-20 text-white">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <span className="text-gold font-bold uppercase tracking-wider text-sm">Notre Engagement</span>
                <h2 className="text-3xl md:text-4xl font-headline font-bold leading-tight">
                  Un accompagnement complet de l&apos;analyse à la résolution
                </h2>
                <p className="text-white/70 text-lg leading-relaxed">
                  Nous agissons comme votre représentant exclusif au Maroc. Notre équipe d&apos;experts prend en charge l&apos;intégralité de votre dossier pour vous offrir une sérénité totale.
                </p>
              </div>

              <ul className="space-y-4">
                {[
                  "Transparence totale sur l'avancement",
                  "Expertise juridique pluridisciplinaire",
                  "Modèle basé sur le résultat",
                  "Représentation légale certifiée"
                ].map((text, idx) => (
                  <li key={idx} className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-gold shrink-0" />
                    <span className="font-medium">{text}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-3xl p-8 lg:p-12 space-y-8 shadow-2xl">
               <div className="grid grid-cols-2 gap-6">
                  <div className="text-center p-6 rounded-2xl bg-white/5 border border-white/5">
                     <div className="text-3xl font-headline font-bold text-gold mb-1">15+</div>
                     <div className="text-xs text-white/60 uppercase font-bold tracking-widest">Ans d&apos;Expérience</div>
                  </div>
                  <div className="text-center p-6 rounded-2xl bg-white/5 border border-white/5">
                     <div className="text-3xl font-headline font-bold text-gold mb-1">98%</div>
                     <div className="text-xs text-white/60 uppercase font-bold tracking-widest">Taux de Succès</div>
                  </div>
                  <div className="text-center p-6 rounded-2xl bg-white/5 border border-white/5">
                     <div className="text-3xl font-headline font-bold text-gold mb-1">450+</div>
                     <div className="text-xs text-white/60 uppercase font-bold tracking-widest">Dossiers Clôturés</div>
                  </div>
                  <div className="text-center p-6 rounded-2xl bg-white/5 border border-white/5">
                     <div className="text-3xl font-headline font-bold text-gold mb-1">12</div>
                     <div className="text-xs text-white/60 uppercase font-bold tracking-widest">Experts Dédiés</div>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
