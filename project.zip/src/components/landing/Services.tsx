
import React from 'react';
import Image from 'next/image';
import {PlaceHolderImages} from '@/lib/placeholder-images';
import {ArrowRight, Landmark, Scale} from 'lucide-react';
import {Card, CardContent} from '@/components/ui/card';

export function Services() {
  const landImage = PlaceHolderImages.find(img => img.id === 'service-land');
  const legalImage = PlaceHolderImages.find(img => img.id === 'service-legal');

  return (
    <section id="services" className="py-24 bg-muted/30">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <h2 className="text-3xl md:text-4xl font-headline font-bold text-secondary mb-6">Nos Domaines d&apos;Expertise</h2>
          <p className="text-muted-foreground text-lg">Des solutions sur mesure pour sécuriser votre patrimoine au Maroc.</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Service 1: Gestion Foncière */}
          <Card className="overflow-hidden border-none shadow-xl group rounded-3xl">
            <div className="relative h-64 overflow-hidden">
               <Image 
                src={landImage?.imageUrl || ''} 
                alt="Gestion Foncière" 
                fill 
                className="object-cover group-hover:scale-105 transition-transform duration-500"
               />
               <div className="absolute inset-0 bg-gradient-to-t from-secondary via-secondary/20 to-transparent" />
               <div className="absolute bottom-6 left-6 flex items-center gap-3">
                 <div className="p-2 rounded-lg bg-gold text-secondary shadow-lg">
                   <Landmark className="w-6 h-6" />
                 </div>
                 <h3 className="text-2xl font-headline font-bold text-white uppercase tracking-wider">Gestion Foncière</h3>
               </div>
            </div>
            <CardContent className="p-8 space-y-6">
               <p className="text-muted-foreground leading-relaxed">
                 Régularisation de titres, bornage, immatriculation foncière (Conservation Foncière) et audit de patrimoine.
               </p>
               <ul className="space-y-3">
                 {[
                   "Immatriculation foncière (Titre Foncier)",
                   "Sortie d'indivision et partage",
                   "Mise à jour des constructions",
                   "Levée d'hypothèques et de saisies"
                 ].map((item, idx) => (
                   <li key={idx} className="flex items-center gap-3 text-sm font-medium text-secondary">
                     <ArrowRight className="w-4 h-4 text-gold" />
                     {item}
                   </li>
                 ))}
               </ul>
            </CardContent>
          </Card>

          {/* Service 2: Conseil Juridique */}
          <Card className="overflow-hidden border-none shadow-xl group rounded-3xl">
            <div className="relative h-64 overflow-hidden">
               <Image 
                src={legalImage?.imageUrl || ''} 
                alt="Conseil Juridique" 
                fill 
                className="object-cover group-hover:scale-105 transition-transform duration-500"
               />
               <div className="absolute inset-0 bg-gradient-to-t from-secondary via-secondary/20 to-transparent" />
               <div className="absolute bottom-6 left-6 flex items-center gap-3">
                 <div className="p-2 rounded-lg bg-gold text-secondary shadow-lg">
                   <Scale className="w-6 h-6" />
                 </div>
                 <h3 className="text-2xl font-headline font-bold text-white uppercase tracking-wider">Conseil Juridique</h3>
               </div>
            </div>
            <CardContent className="p-8 space-y-6">
               <p className="text-muted-foreground leading-relaxed">
                 Accompagnement dans les transactions, gestion des litiges et conseil successoral complexe.
               </p>
               <ul className="space-y-3">
                 {[
                   "Accompagnement à l'achat / vente",
                   "Droit des successions (Étranger/Maroc)",
                   "Gestion des litiges locatifs",
                   "Rédaction d'actes et conventions"
                 ].map((item, idx) => (
                   <li key={idx} className="flex items-center gap-3 text-sm font-medium text-secondary">
                     <ArrowRight className="w-4 h-4 text-gold" />
                     {item}
                   </li>
                 ))}
               </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
