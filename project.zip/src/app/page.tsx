
import {Navbar} from '@/components/landing/Navbar';
import {Hero} from '@/components/landing/Hero';
import {ProblemSolution} from '@/components/landing/ProblemSolution';
import {HowItWorks} from '@/components/landing/HowItWorks';
import {Services} from '@/components/landing/Services';
import {Testimonials} from '@/components/landing/Testimonials';
import {Confidentiality} from '@/components/landing/Confidentiality';
import {LeadForm} from '@/components/forms/LeadForm';
import {Footer} from '@/components/landing/Footer';
import {CTAFloating} from '@/components/landing/CTAFloating';

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navbar />
      
      <Hero />
      
      <ProblemSolution />
      
      <HowItWorks />
      
      <Services />
      
      <Testimonials />
      
      <Confidentiality />
      
      {/* Contact Section */}
      <section id="contact" className="py-24 bg-white relative">
        <div className="absolute top-0 inset-x-0 h-1/2 bg-muted/30" />
        <div className="max-w-7xl mx-auto px-6 lg:px-12 relative z-10 grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <span className="text-gold font-bold uppercase tracking-wider text-sm">Contactez-nous</span>
              <h2 className="text-3xl md:text-5xl font-headline font-bold text-secondary leading-tight">
                Prêt à régulariser votre situation ?
              </h2>
              <p className="text-muted-foreground text-lg leading-relaxed">
                Remplissez ce formulaire pour une première analyse gratuite de votre dossier. Un de nos experts reviendra vers vous avec une stratégie sur mesure.
              </p>
            </div>

            <div className="space-y-6">
              {[
                { title: "Réponse sous 24h", desc: "Nous traitons chaque demande avec priorité et rigueur." },
                { title: "Analyse experte", desc: "Premier diagnostic juridique sans engagement." },
                { title: "Support multilingue", desc: "Français, Arabe, Anglais, Darija." }
              ].map((item, idx) => (
                <div key={idx} className="flex gap-4">
                  <div className="w-2 h-2 rounded-full bg-gold mt-2 shrink-0" />
                  <div>
                    <h4 className="font-headline font-bold text-secondary">{item.title}</h4>
                    <p className="text-muted-foreground text-sm">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <LeadForm />
        </div>
      </section>

      <Footer />
      
      <CTAFloating />
    </main>
  );
}
