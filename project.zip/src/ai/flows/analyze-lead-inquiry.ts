'use server';
/**
 * @fileOverview This file defines a Genkit flow for analyzing client inquiries.
 *
 * - analyzeLeadInquiry - A function that processes client inquiry text to extract key information.
 * - AnalyzeLeadInquiryInput - The input type for the analyzeLeadInquiry function.
 * - AnalyzeLeadInquiryOutput - The return type for the analyzeLeadInquiry function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnalyzeLeadInquiryInputSchema = z.object({
  inquiryText: z
    .string()
    .describe('The full text of the client inquiry submitted via the form.'),
});
export type AnalyzeLeadInquiryInput = z.infer<typeof AnalyzeLeadInquiryInputSchema>;

const AnalyzeLeadInquiryOutputSchema = z.object({
  summary: z
    .string()
    .describe('A concise summary of the client inquiry, highlighting the main issue.'),
  keyLegalTerms: z
    .array(z.string())
    .describe('An array of key legal terms identified in the inquiry text.'),
  caseCategories: z
    .array(z.enum(['inheritance', 'land dispute', 'administrative complexity', 'general legal advisory', 'other']))
    .describe('An array of categories that best describe the client\'s case.'),
});
export type AnalyzeLeadInquiryOutput = z.infer<typeof AnalyzeLeadInquiryOutputSchema>;

export async function analyzeLeadInquiry(
  input: AnalyzeLeadInquiryInput
): Promise<AnalyzeLeadInquiryOutput> {
  return analyzeLeadInquiryFlow(input);
}

const analyzeLeadInquiryPrompt = ai.definePrompt({
  name: 'analyzeLeadInquiryPrompt',
  input: {schema: AnalyzeLeadInquiryInputSchema},
  output: {schema: AnalyzeLeadInquiryOutputSchema},
  prompt: `You are an expert legal assistant specialized in Moroccan land management and legal advisory.
Your task is to analyze client inquiries and extract essential information to help legal administrators quickly understand and prioritize cases.

Analyze the following client inquiry text:

Client Inquiry: {{{inquiryText}}}

Based on the inquiry, provide:
1. A concise summary of the client's main issue.
2. A list of key legal terms or concepts mentioned.
3. Identify the primary category or categories for this case from the following options: 'inheritance', 'land dispute', 'administrative complexity', 'general legal advisory', 'other'. If multiple categories apply, list all relevant ones.

Ensure your output strictly adheres to the JSON schema provided.`,
});

const analyzeLeadInquiryFlow = ai.defineFlow(
  {
    name: 'analyzeLeadInquiryFlow',
    inputSchema: AnalyzeLeadInquiryInputSchema,
    outputSchema: AnalyzeLeadInquiryOutputSchema,
  },
  async input => {
    const {output} = await analyzeLeadInquiryPrompt(input);
    return output!;
  }
);
