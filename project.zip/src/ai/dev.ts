import { config } from 'dotenv';
config();

import '@/ai/flows/analyze-lead-inquiry.ts';