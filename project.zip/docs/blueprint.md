# **App Name**: MoroccanLegalBridge

## Core Features:

- Interactive Lead Submission Form: A clean, multi-field form in the contact section for prospective clients to submit their details and specific situation.
- Dynamic Content Presentation: Sections to display the company's offerings, methodology (How it Works), problem descriptions, solutions, and general information.
- Strategic Call-to-Action Implementation: Integration of a sticky Call-to-Action button and a floating WhatsApp button to encourage user engagement and conversions.
- Trust & Credibility Display: Dedicated sections for displaying testimonials, key figures (e.g., cases handled, success rate), and professional credibility elements.
- Confidentiality Assurance Visuals: Visually emphasized section to reassure users about the discretion and privacy of their information and cases.
- Automated Inquiry Analysis Tool: A generative AI tool that analyzes submitted client inquiries from the form to identify keywords, categorize the case type (e.g., inheritance, land dispute), and help with initial lead qualification for the legal team.
- Secure Lead Data Storage: Backend functionality to securely store all submitted client inquiries and contact details from the form for subsequent follow-up and management.

## Style Guidelines:

- Primary action color: Gold (#F5A623). Used for interactive elements, CTA buttons, and key highlights to convey value and grab attention. HSL: (41, 91%, 55%).
- Main background and brand color: Deep Corporate Blue (#002855). Employed in the hero section, footer, and other dominant brand areas to establish trust and professionalism. Complementary content backgrounds will utilize white (#FFFFFF) and light grey (#F8F8F8) for clarity. HSL of dark blue: (213, 100%, 17%).
- Subtle accent color: Muted Terracotta (#CCA18B). An analogous hue to the primary gold, used for decorative elements, soft dividers, or secondary interactive states to add warmth and understated luxury. HSL: (11, 30%, 60%).
- Headline font: 'Playfair' (serif) for an elegant, high-end feel in titles and strong headings, conveying subtle luxury and formality. Body text font: 'PT Sans' (sans-serif) for clear readability and a modern yet approachable tone in longer content blocks.
- Minimalist, line-based icons for clarity and modern appeal. Custom icons will be designed for trust badges and section indicators, maintaining the clean, corporate aesthetic.
- A mobile-first responsive layout with generous clear spacing, section separation, and consistent padding. UI elements will feature soft shadows and subtly rounded cards to add depth and a premium touch.
- Subtle, fluid transitions and micro-animations on hover or scroll. These will be kept minimal and sophisticated to enhance user experience without being flashy, aligning with the discreet luxury feel.